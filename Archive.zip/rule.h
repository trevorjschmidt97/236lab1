//
//  rule.h
//  lexicalAnalysis
//
//  Created by Trevor Schmidt on 9/27/19.
//  Copyright © 2019 Trevor Schmidt. All rights reserved.
//

#ifndef rule_h
#define rule_h

#include <stdio.h>

#endif /* rule_h */
