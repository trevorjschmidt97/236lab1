//
//  predicate.h
//  lexicalAnalysis
//
//  Created by Trevor Schmidt on 9/27/19.
//  Copyright © 2019 Trevor Schmidt. All rights reserved.
//

#ifndef predicate_h
#define predicate_h

#include <stdio.h>

#endif /* predicate_h */
