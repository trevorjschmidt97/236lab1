//
//  token.cpp
//  lexicalAnalysis
//
//  Created by Trevor Schmidt on 9/18/19.
//  Copyright © 2019 Trevor Schmidt. All rights reserved.
//

#include "token.h"

using namespace std;


